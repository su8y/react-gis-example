import React, {useContext, useEffect, useState} from 'react';
import MapContext from "./map/MapContext";
import {OSMlayers, WMSImageLayer} from "./map/openlayers_map";
import LayerSelect from "./component/LayerSelect";
import MapInfoBox from "./component/MapInfoBox";
import styled from "styled-components";


function App() {

    const {instance, isLoading} = useContext(MapContext)

    const handleZoomIn = () => {
        instance.getView().setZoom(10);
    }


    return (<>
        {
            isLoading ? <div>none</div> : <>
                <MapInfoBox></MapInfoBox></>
        }
        <MapTemplate id={'map'}></MapTemplate>
    </>);
}

const MapTemplate = styled.div`
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 100%;
`


export default App;
