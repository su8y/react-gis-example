import {View} from 'ol';
import TileLayer from 'ol/layer/Tile';
import OSM from 'ol/source/OSM';
import ImageLayer from "ol/layer/Image.js";
import {ImageWMS} from "ol/source.js";
import VectorSource from "ol/source/Vector";
import VectorLayer from "ol/layer/Vector";
import {Stroke, Style} from "ol/style";
import {bbox as bboxStrategy} from 'ol/loadingstrategy'
import {GeoJSON} from "ol/format";

export const wmsSource = new ImageWMS({
    url: 'http://localhost/geoserver/wms',
    // url: 'http://localhost:80/geoserver/cite/wms?service=WMS&version=1.1.0&request=GetMap&layers=cite%3Agisexample&bbox=-180.0%2C-90.0%2C180.0%2C90.0&width=768&height=384&srs=EPSG%3A4326&styles=&format=image%2Fsvg%20xml',
    params: {'LAYERS': 'ne:countries'},
    ratio: 1,
    crossOrigin: 'anonymous',
    serverType: 'geoserver',
});
export const WMSImageLayer = [new ImageLayer({
    source: wmsSource
})]

export const OSMlayers = [
    new TileLayer({
        source: new OSM(),
        properties: {
            name: "base-osm"
        }
    })
];
export const view = new View({
    center: [0, 0],
    zoom: 3,
    projection: 'EPSG:3857'
})



export const wfsLayers = new VectorLayer({
    style: new Style({
        stroke: new Stroke({
            color: 'rgba(0, 0, 255, 1.0)',
            width: 2,
        }),
    }),
});
